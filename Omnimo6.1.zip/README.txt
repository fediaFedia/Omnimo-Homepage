Omnimo 6.1 by Xyrfo and fediaFedia


NEW USERS / CLEAN INSTALL

If you have Rainmeter installed, just double click Omnimo.rmskin
If not, launch Setup.exe and follow the instructions to download Rainmeter, after you've installed it, Omnimo will be installed by the installer.


ATTENTION! EXISTING USERS!

You might want to make a backup of your WP7 folder just in case. The new version will overwrite all your Omnimo files and settings. 
Since this is a major release, we cannot offer any upgrade options.

Navigate to your Documents\Rainmeter\Skins folder and rename WP7 to something else, for instance, WP7_backup before installing.


--

Please visit our website at http://omnimo.info for more info.
You'll also find the Customization Guide, Add-ons and other Goodies there.