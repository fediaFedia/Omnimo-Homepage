Omnimo 6.1 LITE by Xyrfo and fediaFedia

Is this entirely new to you? 
Then download the regular version at http://omnimo.info
It's more user friendly

NEW USERS / CLEAN INSTALL

If you have Rainmeter installed, just double click Omnimo.rmskin
If not, run extract the archive and run setup.exe

PLEASE NOTE: Installing Omnimo 6.1 (non-lite) may overwrite your settings later. You can make a backup of the Documents\Rainmeter\WP7\@Resources\Config, install Omnimo 6.1 and then copy the backed up folder to WP7\@Resources\Config overwriting all changes. This should keep your settings.

Omnimo 6.1 Lite will NOT overwrite the settings of Omnimo 6.1

ATTENTION! EXISTING USERS!

You might want to make a backup of your WP7 folder just in case. The new version will overwrite all your Omnimo files and settings. 
Since this is a major release, we cannot offer any upgrade options.

Navigate to your Documents\Rainmeter\Skins folder and rename WP7 to something else, for instance, WP7_backup before installing.


--

Please visit our website at http://omnimo.info for more info.
You'll also find the Customization Guide, Add-ons and other Goodies there.